#IANshowloading

### 说明：
- https://github.com/ianisme/IANshowLoading
- 可以添加到指定view上，保证各个控制器之间的loading动画不会相互影响

### 效果演示：
<img src="https://coding.net/u/ianisme/p/IANshowloading/git/raw/master/Demo.gif"  alt="效果展示by ian" height="568" width="320" />